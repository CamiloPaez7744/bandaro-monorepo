# Emerald Velocity Design System

### 1. Overview & Creative North Star
**Creative North Star: "The Tactical Edge"**
Emerald Velocity is a high-performance design system built for mastery and precision. Inspired by professional billiards and precision sports, it moves away from generic administrative layouts toward a "Digital Coach" aesthetic. The system utilizes deep botanical greens, high-contrast emerald accents, and a "Tonal Stacking" methodology to create a focused, immersive training environment. It breaks the grid through status-driven card variations and intentional depth markers.

### 2. Colors
Emerald Velocity relies on a deep-sea palette punctuated by vibrant, bioluminescent highlights.

- **Primary & Accent:** The core is `#064c39` (Deep Forest) for stability, while `#10b981` (Emerald Accent) is used for kinetic energy—success states, trends, and active progression.
- **The "No-Line" Rule:** Visual sectioning is achieved through color blocks rather than borders. Use the transition from `surface` (`#0a0f0d`) to `surface_container` (`#162521`) to define content areas. If a boundary is absolutely required, use a low-opacity `primary` tint (e.g., `primary/20`) rather than gray.
- **Surface Hierarchy & Nesting:** 
    - **Background:** `#0a0f0d` (Pure Base).
    - **Cards/Modules:** `#162521` (Surface Container).
    - **Active/Hover:** `#1c2e29` (Surface Container High).
- **Signature Textures:** Use linear gradients from `primary` to a darker `emerald-900` for high-impact cards. These should feel like physical objects with depth, utilizing a 10-15% opacity icon overlay for textural complexity.

### 3. Typography
The system uses **Inter** for its clean, functional clarity, paired with **Roboto** for high-density statistical data.

- **Typography Scale:**
    - **Display (1.875rem / 30px):** Bold, used for hero numbers and primary stats. High impact, high visibility.
    - **Headline (1.25rem / 20px):** Semi-bold, used for section titles and brand identification.
    - **Title/Base (1rem / 16px):** Medium/Bold, used for primary list items and card titles.
    - **Body (0.875rem / 14px):** Regular, for descriptions and secondary metadata.
    - **Labels (0.75rem / 12px & 10px):** Bold Uppercase for tags (e.g., "DONE", "WEEK 12"), creating a "flight instrument" feel.
- **Typographic Rhythm:** The system uses tight leading (leading-tight) for headlines to maintain a compact, "pro-tool" density.

### 4. Elevation & Depth
Emerald Velocity avoids heavy shadows, favoring light and translucency.

- **The Layering Principle:** Content sits on `surface_container`. Interactive elements are highlighted by an `absolute` left-border accent of 4px in `accent-emerald` to indicate "Current" or "Active" states.
- **Ambient Shadows:** Only use two levels of shadow:
    - `shadow-sm`: For standard cards to lift them slightly from the base.
    - `shadow-lg`: Reserved for floating action bars or high-priority coach recommendations.
- **Glassmorphism & Depth:** The bottom navigation bar must use a `backdrop-blur-md` with an 80% opacity background (`surface/80`). This creates a sense of the interface floating over the content stream.

### 5. Components
- **Buttons:**
    - **Primary CTA:** Pill-shaped (rounded-full), white text on primary background for high contrast.
    - **Status Chips:** Small, rectangular with subtle rounding (4px), using low-opacity primary backgrounds (10-20%) and high-saturation text.
- **Cards:** Use `rounded-xl` (1rem) for standard modules. Add a 1px border of `primary/10` to define the shape against the dark background without creating a hard visual stop.
- **Progress Indicators:** Horizontal bars should use a high-contrast track (`surface_container_highest`) and a vibrant primary fill.
- **Lists:** Timeline-style lists use an "Active Stripe" on the left edge. Locked or future items should drop to 40% opacity with a dashed border to indicate "Potential" vs "Reality."

### 6. Do's and Don'ts
- **Do:** Use color intensity to signify progress. The more "Emerald" an element, the closer it is to mastery.
- **Do:** Mix font weights (Bold 700 vs Regular 400) within the same line to create immediate hierarchy in small spaces.
- **Don't:** Use standard gray borders. They break the immersive "Night Mode" feel of the system.
- **Don't:** Overuse shadows. Let the shift from `#0a0f0d` to `#162521` do the work of defining space.
- **Do:** Ensure all interactive icons have a `size-12` touch target but a smaller visual icon to maintain a sophisticated, "fitted" look.